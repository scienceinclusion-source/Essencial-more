
export type PaymentMethod = 'DINHEIRO' | 'CARTAO' | 'PIX' | 'CREDITO_LOJA'; // CREDITO_LOJA = Fiado

export type TransactionType = 'SALE' | 'DEBT_PAYMENT';

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  image: string;
  stock: number;
  description?: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string; // Mantido para compatibilidade, mas opcional
  phone: string;
  totalSpent: number; // Total comprado na vida
  balance: number; // Saldo Devedor (Fiado)
  purchaseHistory: string[]; // IDs das vendas
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Sale {
  id: string;
  type: TransactionType; // Venda ou Pagamento de Dívida
  customerId: string | null;
  customerName: string;
  date: string; // ISO string com Hora
  dueDate?: string; // Data de Vencimento (para Venda a Prazo)
  items: {
    productId: string;
    productName: string;
    quantity: number;
    priceAtSale: number;
  }[];
  total: number;
  paymentMethod: PaymentMethod;
  installments?: number; // Para cartão de crédito (1x a 12x)
  observation?: string; // Detalhes extras
}

export type ViewState = 'DASHBOARD' | 'POS' | 'INVENTORY' | 'CUSTOMERS';
