
import React, { useState, useEffect } from 'react';
import { Customer, Sale, PaymentMethod } from '../types';
import { Search, Phone, ShoppingBag, X, User, Edit, Trash2, CheckCircle, Loader2, Plus, AlertTriangle, DollarSign, Wallet, Calendar, ArrowDownCircle, Banknote } from 'lucide-react';
import { StorageService } from '../services/storage';

interface CustomersProps {
  customers: Customer[];
  sales: Sale[];
  onAddCustomer: (c: Customer) => Promise<void>;
  onProcessPayment: (customerId: string, amount: number, method: PaymentMethod) => Promise<void>;
  onDeleteCustomer: (id: string) => Promise<void>;
  onDeleteSale: (saleId: string) => Promise<void>;
}

type DebtModalType = 'PARTIAL' | 'FULL' | null;

export const Customers: React.FC<CustomersProps> = ({ 
    customers, 
    sales, 
    onAddCustomer, 
    onProcessPayment,
    onDeleteCustomer,
    onDeleteSale 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  
  // Alterado para armazenar apenas o ID, assim quando 'customers' atualizar, o 'selectedCustomer' recalculado terá os dados novos
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Debt Management
  const [debtModalType, setDebtModalType] = useState<DebtModalType>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [debtAmount, setDebtAmount] = useState<string>('');
  const [debtMethod, setDebtMethod] = useState<PaymentMethod>('DINHEIRO');

  // Form State
  const [formData, setFormData] = useState({ id: '', name: '', phone: '' });
  const [isEditing, setIsEditing] = useState(false);

  // Derivar o cliente selecionado dos dados mais recentes
  const selectedCustomer = selectedCustomerId 
    ? customers.find(c => c.id === selectedCustomerId) || null 
    : null;

  // Se o cliente selecionado for deletado ou sumir, fecha o painel
  useEffect(() => {
    if (selectedCustomerId && !selectedCustomer) {
        setSelectedCustomerId(null);
    }
  }, [customers, selectedCustomerId]);

  // Filter
  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.phone.includes(searchTerm)
  );

  const customerSales = selectedCustomer 
    ? sales.filter(s => s.customerId === selectedCustomer.id).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    : [];

  const handleOpenModal = (customer?: Customer) => {
    if (customer) {
      setFormData({ id: customer.id, name: customer.name, phone: customer.phone });
      setIsEditing(true);
    } else {
      setFormData({ id: '', name: '', phone: '' });
      setIsEditing(false);
    }
    setIsModalOpen(true);
  };

  const handleOpenDebtModal = (type: 'PARTIAL' | 'FULL') => {
      if (!selectedCustomer) return;
      setDebtModalType(type);
      setDebtMethod('DINHEIRO');
      if (type === 'FULL') {
          setDebtAmount(selectedCustomer.balance.toFixed(2));
      } else {
          setDebtAmount('');
      }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    setIsSaving(true);
    try {
        const customerData: any = {
            name: formData.name,
            phone: formData.phone,
            email: '',
            // Preservar dados financeiros
            totalSpent: isEditing && selectedCustomer ? selectedCustomer.totalSpent : 0,
            balance: isEditing && selectedCustomer ? selectedCustomer.balance : 0,
            purchaseHistory: isEditing && selectedCustomer ? selectedCustomer.purchaseHistory : []
        };

        if (isEditing) {
            customerData.id = formData.id;
        } else {
            customerData.id = ''; 
        }

        await onAddCustomer(customerData);
        setIsModalOpen(false);
    } catch (e) {
        alert("Erro ao salvar cliente.");
    } finally {
        setIsSaving(false);
    }
  };

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm("ATENÇÃO: Isso excluirá o cliente permanentemente. Deseja continuar?")) {
       await onDeleteCustomer(id);
       setSelectedCustomerId(null); // Fecha o painel
    }
  };

  const handleDeleteTransaction = async (saleId: string) => {
     if(confirm("Tem certeza que deseja EXCLUIR/ESTORNAR esta movimentação? Se for uma venda, os itens voltarão ao estoque e o saldo do cliente será corrigido.")) {
         await onDeleteSale(saleId);
     }
  };

  const handlePayDebt = async () => {
      const amount = parseFloat(debtAmount);
      if (!amount || amount <= 0 || !selectedCustomer) return;

      if (amount > selectedCustomer.balance + 0.01) { // margem de erro float
          alert("Valor maior que a dívida.");
          return;
      }

      setIsSaving(true);
      try {
          await onProcessPayment(selectedCustomer.id, amount, debtMethod);
          setDebtModalType(null);
          setDebtAmount('');
      } catch (e) {
          console.error(e);
      } finally {
          setIsSaving(false);
      }
  };

  return (
    <div className="flex h-[calc(100vh-120px)] gap-8 animate-fade-in pb-20">
      {/* List */}
      <div className={`flex-1 flex flex-col ${selectedCustomer ? 'hidden lg:flex' : ''}`}>
        <header className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-4xl font-serif font-medium text-caramel-800 mb-1">Clientes</h2>
            <p className="text-caramel-400 font-light">Gerencie saldos e histórico.</p>
          </div>
          <button 
            onClick={() => handleOpenModal()}
            className="bg-caramel-800 text-white px-6 py-3 rounded-full text-xs font-bold uppercase tracking-widest shadow-lg hover:bg-gold-600 transition-colors flex items-center gap-2"
          >
            <Plus size={16} /> Novo Cliente
          </button>
        </header>

        <div className="relative mb-6">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-caramel-300" size={18} />
          <input 
            type="text" 
            placeholder="Buscar por nome ou telefone..." 
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-4 rounded-full bg-white border border-caramel-100 focus:border-gold-300 focus:ring-4 focus:ring-gold-50 outline-none transition-all shadow-sm text-caramel-800 placeholder:text-caramel-300"
          />
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 pr-2">
          {filteredCustomers.map(customer => (
            <div 
              key={customer.id} 
              onClick={() => setSelectedCustomerId(customer.id)}
              className={`group p-4 rounded-2xl border cursor-pointer transition-all flex items-center gap-4 ${
                selectedCustomerId === customer.id 
                  ? 'bg-gold-50 border-gold-300 shadow-md' 
                  : 'bg-white border-transparent hover:border-gold-100 hover:shadow-lg hover:shadow-caramel-100'
              }`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-serif font-bold text-lg shadow-inner ${selectedCustomerId === customer.id ? 'bg-white text-gold-600' : 'bg-caramel-50 text-caramel-400 group-hover:bg-gold-100 group-hover:text-gold-600 transition-colors'}`}>
                {customer.name.charAt(0)}
              </div>
              
              <div className="flex-1">
                <div className="flex justify-between items-center">
                    <h4 className="font-bold text-caramel-800 text-base">{customer.name}</h4>
                    {customer.balance > 0 && (
                        <span className="text-[10px] bg-red-100 text-red-600 font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                           <AlertTriangle size={10} /> -R$ {customer.balance.toFixed(2)}
                        </span>
                    )}
                </div>
                {customer.phone && (
                    <div className="flex items-center gap-1 text-xs text-caramel-400 mt-0.5">
                        <Phone size={10}/> {customer.phone}
                    </div>
                )}
              </div>

              <div className="flex items-center gap-2 opacity-100 lg:opacity-0 group-hover:opacity-100 transition-opacity">
                 <button 
                    onClick={(e) => { e.stopPropagation(); handleOpenModal(customer); }}
                    className="p-2 rounded-full hover:bg-caramel-50 text-caramel-300 hover:text-gold-600 transition-colors"
                    title="Editar"
                 >
                    <Edit size={16} />
                 </button>
                 <button 
                    onClick={(e) => handleDelete(e, customer.id)}
                    className="p-2 rounded-full hover:bg-red-50 text-caramel-300 hover:text-red-500 transition-colors"
                    title="Excluir"
                 >
                    <Trash2 size={16} />
                 </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Details Panel - A Ficha Completa */}
      {selectedCustomer ? (
        <div className="w-full lg:w-[480px] bg-white rounded-3xl shadow-[0_0_50px_-10px_rgba(212,175,55,0.1)] border border-caramel-100 flex flex-col h-full animate-slide-up relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-24 bg-gold-gradient opacity-10" />
          
          <div className="p-8 relative z-10 border-b border-caramel-100">
            <button onClick={() => setSelectedCustomerId(null)} className="absolute top-6 right-6 text-caramel-300 hover:text-caramel-800 lg:hidden">
              <X size={24} />
            </button>
            
            <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-full bg-caramel-50 flex items-center justify-center text-caramel-300 font-serif text-3xl font-bold shadow-inner">
                    {selectedCustomer.name.charAt(0)}
                </div>
                <div>
                    <h3 className="font-serif text-2xl font-bold text-caramel-800 leading-tight">{selectedCustomer.name}</h3>
                    <p className="text-caramel-400 text-sm flex items-center gap-1 mt-1"><Phone size={12}/> {selectedCustomer.phone || "Sem telefone"}</p>
                </div>
            </div>

            {/* Financial Status Card */}
            <div className={`rounded-2xl p-6 mb-4 relative overflow-hidden ${selectedCustomer.balance > 0 ? 'bg-gradient-to-br from-red-50 to-white border border-red-100' : 'bg-gradient-to-br from-emerald-50 to-white border border-emerald-100'}`}>
                <div className="flex justify-between items-start mb-2">
                     <span className={`text-[10px] font-bold uppercase tracking-widest ${selectedCustomer.balance > 0 ? 'text-red-400' : 'text-emerald-500'}`}>
                        {selectedCustomer.balance > 0 ? 'Fatura em Aberto' : 'Tudo em Dia'}
                    </span>
                    <Wallet size={20} className={selectedCustomer.balance > 0 ? 'text-red-300' : 'text-emerald-300'} />
                </div>
                <div className="flex items-baseline gap-1">
                    <span className={`text-3xl font-serif font-bold ${selectedCustomer.balance > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                        R$ {selectedCustomer.balance.toFixed(2)}
                    </span>
                </div>
                
                {selectedCustomer.balance > 0 && (
                    <div className="flex gap-2 mt-4 pt-4 border-t border-red-100/50">
                        <button 
                            onClick={() => handleOpenDebtModal('PARTIAL')}
                            className="flex-1 bg-white border border-red-200 text-red-600 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider hover:bg-red-50 transition-colors"
                        >
                            Abater Valor
                        </button>
                        <button 
                             onClick={() => handleOpenDebtModal('FULL')}
                             className="flex-1 bg-red-600 text-white py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider hover:bg-red-700 transition-colors shadow-lg shadow-red-200"
                        >
                            Quitar Total
                        </button>
                    </div>
                )}
            </div>

            <div className="bg-caramel-50/50 rounded-xl p-3 flex justify-between items-center">
                 <span className="text-xs text-caramel-500">Total Comprado (Lifetime)</span>
                 <span className="font-bold text-caramel-800">R$ {selectedCustomer.totalSpent.toFixed(2)}</span>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-8 bg-white">
            <h4 className="font-bold text-caramel-800 mb-6 flex items-center gap-2 uppercase text-xs tracking-widest">
              <ShoppingBag size={16} className="text-gold-500" />
              Extrato Detalhado
            </h4>
            
            <div className="space-y-4">
              {customerSales.length === 0 ? (
                <div className="text-center py-10 rounded-2xl border border-dashed border-caramel-100">
                    <p className="text-caramel-400 text-sm italic">Nenhuma movimentação.</p>
                </div>
              ) : (
                customerSales.map((sale) => (
                  <div key={sale.id} className={`p-4 rounded-xl border relative group ${
                      sale.type === 'DEBT_PAYMENT' 
                        ? 'bg-emerald-50/50 border-emerald-100' 
                        : sale.paymentMethod === 'CREDITO_LOJA' 
                            ? 'bg-red-50/30 border-red-100' 
                            : 'bg-caramel-50 border-caramel-100'
                  }`}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-xs font-bold text-caramel-400">
                            {new Date(sale.date).toLocaleDateString()}
                        </span>
                        
                        <div className="flex gap-2 items-center">
                            {/* Delete Transaction Button - Only visible on hover/touch */}
                            <button 
                                onClick={() => handleDeleteTransaction(sale.id)}
                                className="opacity-0 group-hover:opacity-100 p-1 text-caramel-300 hover:text-red-500 transition-all"
                                title="Estornar/Excluir Transação"
                            >
                                <Trash2 size={12} />
                            </button>

                            {sale.type === 'DEBT_PAYMENT' ? (
                                <span className="text-[9px] font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded uppercase flex items-center gap-1">
                                    <ArrowDownCircle size={10} /> Pagamento
                                </span>
                            ) : (
                                <span className={`text-[9px] font-bold border px-2 py-0.5 rounded uppercase flex items-center gap-1 ${
                                    sale.paymentMethod === 'CREDITO_LOJA' 
                                    ? 'bg-red-100 text-red-700 border-red-200' 
                                    : 'bg-white text-caramel-500 border-caramel-200'
                                }`}>
                                    {sale.paymentMethod === 'CREDITO_LOJA' ? 'A Prazo' : sale.paymentMethod}
                                    {sale.installments && sale.installments > 1 && ` (${sale.installments}x)`}
                                </span>
                            )}
                        </div>
                      </div>

                      {/* Itens da Venda ou Descrição */}
                      <div className="space-y-1 mb-3">
                         {sale.items.length > 0 ? (
                            sale.items.map((item, i) => (
                                <div key={i} className="flex justify-between text-sm">
                                    <span className="text-caramel-600">{item.productName} <span className="text-caramel-400 text-xs">x{item.quantity}</span></span>
                                    <span className="text-caramel-400">R$ {(item.priceAtSale * item.quantity).toFixed(2)}</span>
                                </div>
                            ))
                         ) : (
                             <div className="text-sm text-caramel-600 italic">Abatimento de dívida</div>
                         )}
                      </div>

                      {/* Vencimento for Debt */}
                      {sale.paymentMethod === 'CREDITO_LOJA' && sale.dueDate && (
                          <div className="flex items-center gap-1 text-[10px] text-red-400 font-bold mb-2 uppercase tracking-wide">
                              <Calendar size={10} /> Vencimento: {new Date(sale.dueDate).toLocaleDateString()}
                          </div>
                      )}
                      
                      <div className="border-t border-dashed border-caramel-300 pt-2 text-right">
                         <span className={`font-serif font-bold text-lg ${sale.type === 'DEBT_PAYMENT' ? 'text-emerald-600' : 'text-caramel-800'}`}>
                            {sale.type === 'DEBT_PAYMENT' ? '-' : ''} R$ {sale.total.toFixed(2)}
                         </span>
                      </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="hidden lg:flex w-[480px] items-center justify-center bg-caramel-50/50 rounded-3xl border border-caramel-100 border-dashed">
           <div className="text-center">
               <div className="w-16 h-16 bg-caramel-100 rounded-full flex items-center justify-center mx-auto mb-4 text-caramel-300">
                   <User size={32} />
               </div>
               <p className="text-caramel-400 font-medium font-serif">Selecione um cliente para ver a ficha</p>
           </div>
        </div>
      )}

      {/* Modal Novo Cliente */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-caramel-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white p-8 rounded-[2rem] shadow-2xl w-full max-w-md animate-slide-up relative">
                <button onClick={() => setIsModalOpen(false)} className="absolute top-4 right-4 text-caramel-300 hover:text-caramel-800">
                    <X size={24} />
                </button>
                <h3 className="font-serif text-2xl font-bold text-caramel-800 mb-6">
                    {isEditing ? 'Editar Cliente' : 'Novo Cliente'}
                </h3>
                <form onSubmit={handleSave} className="space-y-6">
                    <div className="group">
                        <label className="block text-[10px] font-bold text-caramel-400 uppercase tracking-widest mb-2 group-focus-within:text-gold-500">Nome Completo</label>
                        <input 
                            value={formData.name}
                            onChange={e => setFormData({...formData, name: e.target.value})}
                            className="w-full border-b-2 border-caramel-200 py-2 outline-none focus:border-gold-500 font-serif text-xl bg-transparent transition-colors text-caramel-800"
                            placeholder="Nome da cliente"
                            autoFocus
                        />
                    </div>
                    <div className="group">
                        <label className="block text-[10px] font-bold text-caramel-400 uppercase tracking-widest mb-2 group-focus-within:text-gold-500">Telefone</label>
                        <input 
                            value={formData.phone}
                            onChange={e => setFormData({...formData, phone: e.target.value})}
                            className="w-full border-b-2 border-caramel-200 py-2 outline-none focus:border-gold-500 text-lg bg-transparent transition-colors text-caramel-800"
                            placeholder="(00) 00000-0000"
                            type="tel"
                        />
                    </div>
                    <div className="pt-4 flex gap-3">
                        <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-3 rounded-xl font-bold text-caramel-400 hover:text-caramel-800 uppercase text-xs">Cancelar</button>
                        <button type="submit" className="flex-1 bg-caramel-800 text-white py-3 rounded-xl font-bold uppercase text-xs shadow-lg hover:bg-gold-600 transition-colors flex justify-center items-center gap-2">
                             {isSaving && <Loader2 size={14} className="animate-spin" />} Salvar
                        </button>
                    </div>
                </form>
            </div>
        </div>
      )}

      {/* Modal Pagamento Dívida (Dual Mode: Partial or Full) */}
      {debtModalType && selectedCustomer && (
        <div className="fixed inset-0 bg-caramel-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white p-8 rounded-[2rem] shadow-2xl w-full max-w-md animate-slide-up relative">
                <button onClick={() => setDebtModalType(null)} className="absolute top-4 right-4 text-caramel-300 hover:text-caramel-800">
                    <X size={24} />
                </button>
                
                <h3 className="font-serif text-2xl font-bold text-caramel-800 mb-2">
                    {debtModalType === 'FULL' ? 'Quitar Dívida Total' : 'Abater Saldo'}
                </h3>
                <p className="text-caramel-500 text-sm mb-6">
                    {debtModalType === 'FULL' 
                        ? 'Confirmar recebimento do valor total pendente.' 
                        : 'Informe o valor parcial recebido do cliente.'}
                </p>

                <div className="bg-red-50 p-4 rounded-xl mb-6 text-center border border-red-100">
                    <span className="text-xs uppercase tracking-widest text-red-400 font-bold block">Dívida Atual</span>
                    <span className="text-2xl font-serif font-bold text-red-600">R$ {selectedCustomer.balance.toFixed(2)}</span>
                </div>

                <div className="space-y-6">
                    <div className="group">
                        <label className="block text-[10px] font-bold text-caramel-400 uppercase tracking-widest mb-2 group-focus-within:text-gold-500">Valor a Pagar (R$)</label>
                        <div className="relative">
                            <span className="absolute left-0 bottom-2 text-caramel-400 font-serif text-lg">R$</span>
                            <input 
                                type="number"
                                value={debtAmount}
                                onChange={e => setDebtAmount(e.target.value)}
                                className="w-full pl-8 border-b-2 border-caramel-200 py-2 outline-none focus:border-gold-500 font-serif text-2xl bg-transparent transition-colors text-caramel-800"
                                placeholder="0.00"
                                autoFocus={debtModalType === 'PARTIAL'}
                                readOnly={debtModalType === 'FULL'} // Read-only se for quitar total
                            />
                        </div>
                    </div>
                    
                    <div className="group">
                        <label className="block text-[10px] font-bold text-caramel-400 uppercase tracking-widest mb-2">Forma de Pagamento</label>
                        <div className="grid grid-cols-3 gap-2">
                            {['DINHEIRO', 'PIX', 'CARTAO'].map((m) => (
                                <button
                                    key={m}
                                    type="button"
                                    onClick={() => setDebtMethod(m as PaymentMethod)}
                                    className={`py-2 px-1 rounded-lg text-[10px] font-bold uppercase border transition-all ${
                                        debtMethod === m 
                                        ? 'bg-caramel-800 text-white border-caramel-800' 
                                        : 'bg-white text-caramel-400 border-caramel-200 hover:border-gold-300'
                                    }`}
                                >
                                    {m}
                                </button>
                            ))}
                        </div>
                    </div>

                    <button 
                        onClick={handlePayDebt}
                        disabled={isSaving || !debtAmount}
                        className="w-full bg-emerald-600 text-white py-4 rounded-xl font-bold uppercase text-xs shadow-lg hover:bg-emerald-700 transition-colors flex justify-center items-center gap-2 mt-4"
                    >
                        {isSaving && <Loader2 size={14} className="animate-spin" />} 
                        {debtModalType === 'FULL' ? 'Confirmar Quitação' : 'Confirmar Abatimento'}
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
