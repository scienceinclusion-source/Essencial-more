
import React, { useState, useRef } from 'react';
import { Product } from '../types';
import { Plus, Search, X, Edit, Trash, Loader2, Image as ImageIcon, Upload } from 'lucide-react';

interface InventoryProps {
  products: Product[];
  onAddProduct: (p: Product) => Promise<void>;
  onUpdateProduct: (p: Product) => Promise<void>;
  onDeleteProduct: (id: string) => Promise<void>;
}

export const Inventory: React.FC<InventoryProps> = ({ products, onAddProduct, onUpdateProduct, onDeleteProduct }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const initialFormState: Omit<Product, 'id'> = {
    name: '', category: '', price: 0, stock: 1, image: '', description: ''
  };
  const [formData, setFormData] = useState<Product | Omit<Product, 'id'>>(initialFormState);
  const [isEditing, setIsEditing] = useState(false);

  const handleOpenModal = (product?: Product) => {
    if (product) {
      setFormData(product);
      setIsEditing(true);
    } else {
      setFormData(initialFormState);
      setIsEditing(false);
    }
    setIsModalOpen(true);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("A imagem é muito grande. Tente uma menor que 2MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    if (!formData.name || !formData.price || formData.price <= 0) {
      alert("Por favor, preencha o nome e um preço válido.");
      return;
    }
    
    setIsSaving(true);
    try {
      const productToSave = {
        ...formData,
        image: formData.image || 'https://via.placeholder.com/400x500?text=Sem+Foto',
        category: formData.category || 'Geral'
      };

      if (isEditing) {
        await onUpdateProduct(productToSave as Product);
      } else {
        await onAddProduct({
          ...productToSave,
          id: '', 
        } as Product);
      }
      setIsModalOpen(false);
    } catch (e) {
      alert("Erro ao salvar produto.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm("Tem certeza que deseja excluir este produto do estoque?")) {
        await onDeleteProduct(id);
    }
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-fade-in pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-caramel-100/50">
        <div>
           <h2 className="text-4xl font-serif font-medium text-caramel-800 mb-2">Estoque</h2>
           <p className="text-caramel-400 font-light">Gerencie os produtos da loja.</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="group bg-caramel-800 hover:bg-gold-600 text-white px-8 py-4 rounded-full shadow-xl shadow-caramel-200 hover:shadow-gold-200/50 transition-all duration-300 flex items-center gap-3 font-bold tracking-wide text-sm uppercase"
        >
          <Plus size={18} className="group-hover:rotate-90 transition-transform duration-300" /> 
          <span>Adicionar Produto</span>
        </button>
      </header>

      {/* Filters & Search */}
      <div className="flex gap-4 items-center mb-8">
        <div className="relative flex-1 max-w-lg">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-caramel-300" size={20} />
          <input 
            type="text" 
            placeholder="Buscar peças..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-14 pr-6 py-4 rounded-full bg-white border border-caramel-100 shadow-sm focus:border-gold-300 focus:ring-4 focus:ring-gold-50 outline-none transition-all placeholder:text-caramel-300 text-caramel-700"
          />
        </div>
      </div>

      {/* Empty State */}
      {products.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 border-2 border-dashed border-caramel-100 rounded-3xl bg-caramel-50/50">
           <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center text-caramel-300 mb-4 shadow-sm">
             <Upload size={32} />
           </div>
           <h3 className="font-serif text-xl text-caramel-600 mb-2">Estoque Vazio</h3>
           <p className="text-caramel-400 text-sm mb-6">Comece adicionando peças ao seu acervo.</p>
           <button onClick={() => handleOpenModal()} className="text-gold-600 font-bold uppercase text-xs tracking-widest border-b border-gold-300 pb-1">Adicionar agora</button>
        </div>
      )}

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {filteredProducts.map((product, idx) => (
          <div 
            key={product.id} 
            className="group bg-white rounded-3xl p-4 shadow-sm hover:shadow-2xl hover:shadow-gold-100 transition-all duration-500 ease-out border border-transparent hover:border-caramel-50 animate-slide-up flex flex-col"
            style={{ animationDelay: `${idx * 50}ms` }}
          >
            <div className="aspect-[3/4] w-full overflow-hidden rounded-2xl relative bg-caramel-50 mb-4">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
              />
              
              <div className="absolute top-3 right-3 flex flex-col gap-2 translate-x-10 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all duration-300 delay-75 z-20">
                <button 
                    onClick={() => handleOpenModal(product)} 
                    className="w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center text-caramel-800 hover:text-gold-600 shadow-lg hover:scale-110 transition-all"
                    title="Editar"
                >
                    <Edit size={16} />
                </button>
                <button 
                    onClick={(e) => handleDelete(e, product.id)}
                    className="w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center text-caramel-800 hover:text-red-500 shadow-lg hover:scale-110 transition-all"
                    title="Excluir"
                >
                    <Trash size={16} />
                </button>
              </div>

              {product.stock <= 3 && product.stock > 0 && (
                <div className="absolute bottom-3 left-3 bg-red-500/90 backdrop-blur-sm text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  Últimas Unidades
                </div>
              )}
               {product.stock === 0 && (
                <div className="absolute inset-0 bg-caramel-900/40 backdrop-blur-[2px] flex items-center justify-center pointer-events-none">
                   <span className="bg-white text-caramel-900 px-4 py-2 rounded-full font-bold uppercase tracking-widest text-xs">Esgotado</span>
                </div>
              )}
            </div>
            
            <div className="px-1 pb-1 flex-1 flex flex-col">
              <div className="flex justify-between items-start mb-1">
                 <p className="text-[10px] font-bold text-caramel-400 tracking-widest uppercase">{product.category}</p>
                 <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    product.stock > 0 ? 'bg-caramel-50 text-caramel-500' : 'bg-red-50 text-red-500'
                }`}>
                  Estoque: {product.stock}
                </span>
              </div>
              <h3 className="font-serif font-bold text-caramel-800 text-lg leading-tight mb-3 line-clamp-2">{product.name}</h3>
              
              <div className="mt-auto pt-3 border-t border-caramel-50">
                <span className="text-2xl font-serif text-caramel-900 block">
                  R$ {product.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal - Professional & Simple */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-caramel-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-[2rem] w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl animate-slide-up relative">
            
            <div className="absolute top-4 right-4 z-10">
              <button onClick={() => setIsModalOpen(false)} className="w-10 h-10 rounded-full bg-caramel-50 hover:bg-caramel-100 flex items-center justify-center text-caramel-400 transition-colors">
                <X size={20} />
              </button>
            </div>

            <div className="flex flex-col md:flex-row h-full">
               {/* Left: Image Upload */}
               <div className="w-full md:w-5/12 bg-caramel-50 p-8 flex flex-col justify-center items-center border-b md:border-b-0 md:border-r border-caramel-100">
                  <div 
                    className="w-full aspect-[3/4] rounded-2xl border-2 border-dashed border-caramel-200 bg-white flex flex-col items-center justify-center overflow-hidden cursor-pointer hover:border-gold-400 transition-colors relative group"
                    onClick={() => fileInputRef.current?.click()}
                  >
                     {formData.image ? (
                        <>
                           <img src={formData.image} className="w-full h-full object-cover" alt="Preview" />
                           <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                              <span className="text-white text-xs font-bold uppercase tracking-widest flex items-center gap-2"><Upload size={14}/> Alterar</span>
                           </div>
                        </>
                     ) : (
                        <div className="text-center p-4">
                           <div className="w-12 h-12 bg-caramel-50 rounded-full flex items-center justify-center mx-auto mb-3 text-caramel-400">
                              <ImageIcon size={24} />
                           </div>
                           <span className="text-xs font-bold text-caramel-500 uppercase tracking-wide block">Carregar Foto</span>
                           <span className="text-[10px] text-caramel-300">Clique para selecionar</span>
                        </div>
                     )}
                     <input 
                       type="file" 
                       ref={fileInputRef} 
                       className="hidden" 
                       accept="image/*"
                       onChange={handleImageUpload}
                     />
                  </div>
               </div>

               {/* Right: Form Data */}
               <div className="w-full md:w-7/12 p-8 md:p-10">
                  <span className="text-xs font-bold text-gold-600 uppercase tracking-widest block mb-1">
                      {isEditing ? 'Editar Produto' : 'Novo Produto'}
                  </span>
                  <h3 className="text-3xl font-serif font-medium text-caramel-800 mb-8">
                    Dados da Peça
                  </h3>

                  <div className="space-y-6">
                     <div className="group">
                        <label className="block text-[10px] font-bold text-caramel-400 uppercase tracking-widest mb-2 group-focus-within:text-gold-500 transition-colors">Nome do Produto</label>
                        <input 
                           type="text" 
                           value={formData.name}
                           onChange={e => setFormData({...formData, name: e.target.value})}
                           className="w-full px-0 py-2 border-b-2 border-caramel-200 bg-transparent focus:border-gold-500 outline-none transition-all font-serif text-xl text-caramel-800 placeholder:text-caramel-300"
                           placeholder="Ex: Blusa Seda Off"
                        />
                     </div>

                     <div className="grid grid-cols-2 gap-6">
                        <div className="group">
                           <label className="block text-[10px] font-bold text-caramel-400 uppercase tracking-widest mb-2 group-focus-within:text-gold-500 transition-colors">Preço (R$)</label>
                           <input 
                              type="number" 
                              value={formData.price}
                              onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})}
                              className="w-full px-0 py-2 border-b-2 border-caramel-200 bg-transparent focus:border-gold-500 outline-none transition-all font-bold text-lg text-caramel-800"
                              placeholder="0.00"
                           />
                        </div>
                        <div className="group">
                           <label className="block text-[10px] font-bold text-caramel-400 uppercase tracking-widest mb-2 group-focus-within:text-gold-500 transition-colors">Qtd. Estoque</label>
                           <input 
                              type="number" 
                              value={formData.stock}
                              onChange={e => setFormData({...formData, stock: parseInt(e.target.value)})}
                              className="w-full px-0 py-2 border-b-2 border-caramel-200 bg-transparent focus:border-gold-500 outline-none transition-all font-bold text-lg text-caramel-800"
                           />
                        </div>
                     </div>

                     <div className="group">
                        <label className="block text-[10px] font-bold text-caramel-400 uppercase tracking-widest mb-2 group-focus-within:text-gold-500 transition-colors">Categoria (Opcional)</label>
                        <input 
                           type="text" 
                           value={formData.category}
                           onChange={e => setFormData({...formData, category: e.target.value})}
                           className="w-full px-0 py-2 border-b-2 border-caramel-200 bg-transparent focus:border-gold-500 outline-none transition-all text-sm text-caramel-600"
                           placeholder="Ex: Vestidos, Calças..."
                        />
                     </div>
                  </div>

                  <div className="mt-10 flex justify-end gap-3">
                     <button 
                       onClick={() => setIsModalOpen(false)}
                       disabled={isSaving}
                       className="px-6 py-3 rounded-xl text-caramel-400 hover:text-caramel-800 font-bold tracking-wide uppercase text-xs transition-colors"
                     >
                       Cancelar
                     </button>
                     <button 
                       onClick={handleSave}
                       disabled={isSaving}
                       className="px-8 py-3 rounded-xl bg-caramel-800 text-white font-bold tracking-wide uppercase text-xs shadow-lg hover:bg-gold-600 hover:shadow-gold-200/50 transition-all transform hover:-translate-y-0.5 flex items-center gap-2"
                     >
                       {isSaving && <Loader2 className="animate-spin" size={14} />}
                       {isEditing ? 'Salvar Alterações' : 'Adicionar ao Estoque'}
                     </button>
                  </div>
               </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
