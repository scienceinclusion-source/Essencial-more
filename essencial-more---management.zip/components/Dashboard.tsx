
import React, { useRef } from 'react';
import { Sale, Product, Customer } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, CreditCard, Banknote, QrCode, FileText, Clock, Wallet, Download, Upload, Database, AlertTriangle } from 'lucide-react';
import { StorageService } from '../services/storage';

interface DashboardProps {
  sales: Sale[];
  products: Product[];
  customers: Customer[];
}

export const Dashboard: React.FC<DashboardProps> = ({ sales, products, customers }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const salesTransactions = sales.filter(s => s.type === 'SALE');
  
  // Totais Gerais
  const totalRevenue = salesTransactions.reduce((acc, sale) => acc + sale.total, 0);
  const totalDebt = customers.reduce((acc, c) => acc + (c.balance || 0), 0);
  
  // Totais por Método
  const totalsByMethod = {
    DINHEIRO: 0,
    PIX: 0,
    CARTAO: 0,
    CREDITO_LOJA: 0
  };

  salesTransactions.forEach(sale => {
    totalsByMethod[sale.paymentMethod] += sale.total;
  });

  // Dados para Gráficos
  const salesByDate = salesTransactions.reduce((acc, sale) => {
    const date = new Date(sale.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    if (!acc[date]) acc[date] = 0;
    acc[date] += sale.total;
    return acc;
  }, {} as Record<string, number>);

  const chartData = Object.keys(salesByDate).map(date => ({
    name: date,
    vendas: salesByDate[date]
  })).slice(-7);

  // --- Handlers de Backup ---
  
  const handleExport = async () => {
    try {
      const json = await StorageService.exportDatabase();
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `backup_essencial_more_${new Date().toISOString().slice(0,10)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      alert("Erro ao exportar dados.");
      console.error(error);
    }
  };

  const handleImportClick = () => {
    if (confirm("ATENÇÃO: Restaurar um backup irá SUBSTITUIR todos os dados atuais pelos do arquivo. Deseja continuar?")) {
        fileInputRef.current?.click();
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
        const content = event.target?.result as string;
        if (content) {
            const result = await StorageService.importDatabase(content);
            if (result.success) {
                alert(result.message);
                window.location.reload(); // Recarrega para refletir dados
            } else {
                alert("Erro: " + result.message);
            }
        }
    };
    reader.readAsText(file);
    // Limpar input
    e.target.value = '';
  };

  const StatCard = ({ title, value, icon: Icon, delay, colorClass }: any) => (
    <div 
      className="glass-card p-6 rounded-2xl flex flex-col justify-between group hover:shadow-xl hover:shadow-gold-100 transition-all duration-500 relative overflow-hidden animate-slide-up border border-caramel-100"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex justify-between items-start mb-4">
          <div className={`p-3 rounded-xl shadow-sm ${colorClass}`}>
            <Icon size={20} className="text-white" />
          </div>
          <span className="text-[10px] font-bold text-caramel-400 uppercase tracking-widest">{title}</span>
      </div>
      <h3 className="text-2xl font-serif font-bold text-caramel-800 tracking-tight">
        {value}
      </h3>
    </div>
  );

  return (
    <div className="space-y-8 pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 animate-fade-in border-b border-caramel-100 pb-6">
        <div>
          <h2 className="text-4xl font-serif font-medium text-caramel-800 mb-2 tracking-tight">Resumo Financeiro</h2>
          <p className="text-caramel-400 font-light text-sm">Detalhamento de vendas e caixa.</p>
        </div>
        <div className="text-right hidden md:block">
           <p className="text-[10px] font-bold text-gold-500 uppercase tracking-widest mb-1">Hoje</p>
           <p className="text-caramel-800 font-serif text-lg">{new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
        </div>
      </header>

      {/* Cards de Métodos de Pagamento */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Vendido no Pix" 
          value={`R$ ${totalsByMethod.PIX.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          icon={QrCode}
          delay={0}
          colorClass="bg-gold-400"
        />
        <StatCard 
          title="Vendido no Cartão" 
          value={`R$ ${totalsByMethod.CARTAO.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          icon={CreditCard}
          delay={100}
          colorClass="bg-gold-500"
        />
        <StatCard 
          title="Vendido em Espécie" 
          value={`R$ ${totalsByMethod.DINHEIRO.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          icon={Banknote}
          delay={200}
          colorClass="bg-caramel-400"
        />
         <StatCard 
          title="Vendido a Prazo" 
          value={`R$ ${totalsByMethod.CREDITO_LOJA.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          icon={FileText}
          delay={300}
          colorClass="bg-caramel-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Chart */}
          <div className="lg:col-span-2 glass-card p-8 rounded-3xl animate-slide-up border border-caramel-100" style={{ animationDelay: '400ms' }}>
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h3 className="text-xl font-serif font-bold text-caramel-800">Evolução de Vendas</h3>
                    <p className="text-xs text-caramel-400 mt-1">Faturamento total nos últimos 7 dias</p>
                </div>
                <div className="text-right">
                    <span className="block text-2xl font-serif font-bold text-gold-500">R$ {totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                    <span className="text-[10px] text-caramel-400 uppercase tracking-widest">Total Geral</span>
                </div>
            </div>
            
            <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 20, right: 0, left: -20, bottom: 0 }}>
                <defs>
                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#D4AF37" stopOpacity={0.8}/>
                    <stop offset="100%" stopColor="#F3E5D8" stopOpacity={0.3}/>
                    </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F3E5D8" />
                <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#B08968', fontSize: 11, fontWeight: 500}} 
                    dy={10}
                />
                <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#B08968', fontSize: 11}} 
                    tickFormatter={(value) => `R$${value/1000}k`} 
                />
                <Tooltip 
                    cursor={{fill: '#FDFBF7', opacity: 0.5}}
                    contentStyle={{ 
                    backgroundColor: '#fff', 
                    borderRadius: '12px', 
                    border: '1px solid #E6CCB2', 
                    boxShadow: '0 4px 15px rgba(212, 175, 55, 0.1)',
                    padding: '12px'
                    }}
                    itemStyle={{ color: '#9C6644', fontWeight: 'bold', fontFamily: 'serif' }}
                    labelStyle={{ color: '#D4AF37', marginBottom: '4px', fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase' }}
                />
                <Bar 
                    dataKey="vendas" 
                    fill="url(#colorSales)" 
                    radius={[6, 6, 0, 0]} 
                    barSize={40}
                    animationDuration={1500}
                />
                </BarChart>
            </ResponsiveContainer>
            </div>
          </div>

          {/* Transaction List */}
          <div className="glass-card rounded-3xl p-0 overflow-hidden flex flex-col h-[450px] animate-slide-up border border-caramel-100" style={{ animationDelay: '500ms' }}>
              <div className="p-6 border-b border-caramel-100 bg-white/50">
                  <h3 className="font-serif font-bold text-caramel-800 text-lg">Histórico Recente</h3>
                  <p className="text-xs text-caramel-400 mt-1">Movimentações de hoje</p>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-white/30">
                  {sales.length === 0 ? (
                      <div className="text-center py-10 text-caramel-300 text-sm italic">Nenhuma venda hoje.</div>
                  ) : (
                      sales.map(sale => (
                          <div key={sale.id} className="flex items-center justify-between p-4 rounded-xl border border-caramel-50 bg-white shadow-sm hover:border-gold-200 transition-colors">
                              <div className="flex items-center gap-3">
                                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                      sale.type === 'DEBT_PAYMENT' 
                                      ? 'bg-emerald-50 text-emerald-600' 
                                      : 'bg-gold-50 text-gold-600'
                                  }`}>
                                      {sale.type === 'DEBT_PAYMENT' ? 'PG' : 'VN'}
                                  </div>
                                  <div>
                                      <p className="text-xs font-bold text-caramel-800">{sale.customerName}</p>
                                      <div className="flex items-center gap-2 text-[10px] text-caramel-400 font-medium uppercase tracking-wide">
                                          <span className="flex items-center gap-1"><Clock size={10} /> {new Date(sale.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                          <span>•</span>
                                          <span className="text-gold-600 font-bold">
                                            {sale.paymentMethod === 'CREDITO_LOJA' ? 'A Prazo' : sale.paymentMethod}
                                          </span>
                                          {sale.installments && sale.installments > 1 && <span>({sale.installments}x)</span>}
                                      </div>
                                  </div>
                              </div>
                              <div className="text-right">
                                  <span className={`block font-serif font-bold text-sm ${sale.type === 'DEBT_PAYMENT' ? 'text-emerald-600' : 'text-caramel-800'}`}>
                                      {sale.type === 'DEBT_PAYMENT' ? '+' : ''} R$ {sale.total.toFixed(2)}
                                  </span>
                              </div>
                          </div>
                      ))
                  )}
              </div>
          </div>
      </div>

      {/* DATA ADMINISTRATION SECTION */}
      <div className="mt-12 pt-8 border-t border-caramel-100 animate-slide-up">
        <h3 className="font-serif text-2xl text-caramel-800 mb-6 flex items-center gap-2">
            <Database size={24} className="text-gold-500" />
            Administração de Dados
        </h3>
        
        <div className="bg-white rounded-3xl p-8 border border-caramel-100 flex flex-col md:flex-row items-center justify-between gap-8 shadow-lg">
            <div>
                <h4 className="font-bold text-caramel-800 mb-2">Backup & Segurança</h4>
                <p className="text-sm text-caramel-500 max-w-md">
                    Seus dados estão salvos neste navegador (IndexedDB). Para garantir segurança ou mudar de dispositivo, faça o download do backup regularmente.
                </p>
                <div className="flex items-center gap-2 mt-4 text-[10px] text-caramel-400 uppercase tracking-widest bg-caramel-50 p-2 rounded-lg w-fit">
                    <AlertTriangle size={12} /> Armazenamento Local: Ativo
                </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
                <button 
                    onClick={handleExport}
                    className="flex items-center justify-center gap-2 bg-caramel-100 text-caramel-800 px-6 py-4 rounded-xl font-bold uppercase text-xs tracking-widest hover:bg-caramel-200 transition-colors"
                >
                    <Download size={16} /> Fazer Backup (Exportar)
                </button>
                
                <button 
                    onClick={handleImportClick}
                    className="flex items-center justify-center gap-2 bg-caramel-800 text-gold-50 px-6 py-4 rounded-xl font-bold uppercase text-xs tracking-widest hover:bg-gold-600 transition-colors shadow-lg"
                >
                    <Upload size={16} /> Restaurar Dados (Importar)
                </button>
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept=".json"
                    onChange={handleFileChange}
                />
            </div>
        </div>
      </div>
    </div>
  );
};
