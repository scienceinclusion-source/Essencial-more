import React, { useState, useEffect } from 'react';
import { Product, CartItem, Customer, PaymentMethod } from '../types';
import { Search, ShoppingBag, Plus, Minus, CheckCircle, CreditCard, Banknote, QrCode, ArrowRight, Loader2, AlertCircle, Crown, ArrowLeft, Calendar, FileText, User, UserPlus, Phone, CalendarDays } from 'lucide-react';

interface POSProps {
  products: Product[];
  customers: Customer[];
  onCompleteSale: (items: CartItem[], customerId: string | null, payment: PaymentMethod, installments: number, dueDate?: string) => Promise<void>;
  onAddCustomer: (customer: Customer) => Promise<void>;
}

type POSStep = 'SHOP' | 'CHECKOUT';

export const POS: React.FC<POSProps> = ({ products, customers, onCompleteSale, onAddCustomer }) => {
  const [step, setStep] = useState<POSStep>('SHOP');
  const [cart, setCart] = useState<CartItem[]>([]);
  
  // Checkout States
  const [productSearch, setProductSearch] = useState('');
  const [customerSearchTerm, setCustomerSearchTerm] = useState('');
  const [isCustomerSearchOpen, setIsCustomerSearchOpen] = useState(false);
  
  // Checkout Form
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CARTAO');
  const [installments, setInstallments] = useState<number>(1);
  const [dueDate, setDueDate] = useState<string>('');
  
  const [status, setStatus] = useState<'IDLE' | 'PROCESSING' | 'SUCCESS' | 'ERROR'>('IDLE');
  const [errorMessage, setErrorMessage] = useState('');

  // Calculations
  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  // Filter Products
  const filteredProducts = products.filter(p => p.name.toLowerCase().includes(productSearch.toLowerCase()));

  // Filter Customers for Autocomplete
  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(customerSearchTerm.toLowerCase()) || 
    c.phone.includes(customerSearchTerm)
  );

  // Initial Due Date (Today + 30)
  useEffect(() => {
    if (paymentMethod === 'CREDITO_LOJA' && !dueDate) {
        const d = new Date();
        d.setDate(d.getDate() + 30);
        setDueDate(d.toISOString().split('T')[0]);
    }
  }, [paymentMethod]);

  const addToCart = (product: Product) => {
    if (product.stock <= 0) return;
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) return prev; 
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const product = products.find(p => p.id === id);
        const maxStock = product ? product.stock : item.quantity;
        const newQty = item.quantity + delta;
        if (newQty < 1) return item;
        if (newQty > maxStock) return item;
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const handleSelectExistingCustomer = (c: Customer) => {
      setCustomerName(c.name);
      setCustomerPhone(c.phone);
      setSelectedCustomerId(c.id);
      setIsCustomerSearchOpen(false);
  };

  const clearCustomer = () => {
      setCustomerName('');
      setCustomerPhone('');
      setSelectedCustomerId(null);
  };

  const handleQuickDate = (days: number) => {
      const d = new Date();
      d.setDate(d.getDate() + days);
      setDueDate(d.toISOString().split('T')[0]);
  };

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    
    // Validação de Nome (Obrigatório para todos)
    if (!customerName.trim()) {
        setErrorMessage("Por favor, informe o nome do cliente.");
        setStatus('ERROR');
        setTimeout(() => setStatus('IDLE'), 3000);
        return;
    }

    // Validação de Fiado (Telefone e Data Obrigatórios)
    if (paymentMethod === 'CREDITO_LOJA') {
        if (!customerPhone.trim()) {
            setErrorMessage("Para vender A Prazo, o telefone é obrigatório.");
            setStatus('ERROR');
            setTimeout(() => setStatus('IDLE'), 3000);
            return;
        }
        if (!dueDate) {
            setErrorMessage("Defina a data de vencimento.");
            setStatus('ERROR');
            setTimeout(() => setStatus('IDLE'), 3000);
            return;
        }
    }

    setStatus('PROCESSING');
    try {
      let finalCustomerId = selectedCustomerId;

      // Se não selecionou um existente da lista, cria um novo agora
      if (!finalCustomerId) {
          const newId = Math.random().toString(36).substr(2, 9);
          const newCustomer: Customer = {
              id: newId,
              name: customerName,
              phone: customerPhone,
              email: '',
              totalSpent: 0,
              balance: 0,
              purchaseHistory: []
          };
          // Cria o cliente antes da venda
          await onAddCustomer(newCustomer);
          finalCustomerId = newId;
      }

      await onCompleteSale(cart, finalCustomerId, paymentMethod, installments, dueDate);
      
      // Reset
      setCart([]);
      clearCustomer();
      setCustomerSearchTerm('');
      setStep('SHOP');
      setInstallments(1);
      setDueDate('');
      setPaymentMethod('CARTAO');
      setStatus('SUCCESS');
      setTimeout(() => setStatus('IDLE'), 3000);
    } catch (e: any) {
      setErrorMessage(e.message || "Erro ao processar venda.");
      setStatus('ERROR');
      setTimeout(() => setStatus('IDLE'), 4000);
    }
  };

  // Success Screen
  if (status === 'SUCCESS') {
    return (
      <div className="flex flex-col items-center justify-center h-full animate-fade-in text-center p-6">
        <div className="w-24 h-24 bg-caramel-800 rounded-full flex items-center justify-center text-gold-400 mb-8 shadow-2xl shadow-caramel-200 animate-pulse-slow border-4 border-gold-100">
          <Crown size={40} strokeWidth={1} />
        </div>
        <h2 className="text-4xl font-serif text-caramel-800 mb-2 italic">Merci!</h2>
        <p className="text-caramel-500 text-sm font-light uppercase tracking-widest mb-10">Venda realizada com sucesso</p>
        <button onClick={() => setStatus('IDLE')} className="px-8 py-3 rounded-full border border-gold-300 text-gold-600 hover:bg-gold-50 font-bold uppercase tracking-widest text-[10px] transition-all">
            Novo Atendimento
        </button>
      </div>
    );
  }

  return (
    <div className="h-full relative">
       {status === 'ERROR' && (
        <div className="absolute top-0 right-0 left-0 mx-auto w-max z-50 bg-red-800 text-white px-6 py-3 rounded-full shadow-xl flex items-center gap-3 animate-fade-in">
          <AlertCircle size={16} />
          <span className="font-bold text-xs uppercase tracking-wider">{errorMessage}</span>
        </div>
      )}

      {/* --- STEP: SHOP --- */}
      {step === 'SHOP' && (
        <div className="flex flex-col lg:flex-row h-full gap-6 animate-slide-up pb-10">
            <div className="flex-1 flex flex-col h-full overflow-hidden">
                <header className="mb-6">
                    <h2 className="text-3xl font-serif text-caramel-800 italic mb-1">Nova Venda</h2>
                    <p className="text-xs text-caramel-400 uppercase tracking-widest">Selecione os produtos</p>
                </header>

                <div className="relative mb-6">
                    <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-caramel-300" size={18} />
                    <input 
                        type="text" 
                        placeholder="Buscar peça..." 
                        className="w-full pl-12 pr-4 py-3 rounded-full bg-white border border-caramel-100 shadow-sm focus:border-gold-300 outline-none transition-all text-sm text-caramel-800 placeholder:text-caramel-300"
                        value={productSearch}
                        onChange={e => setProductSearch(e.target.value)}
                    />
                </div>

                <div className="flex-1 overflow-y-auto pr-2 pb-20 lg:pb-0">
                    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                        {filteredProducts.map(product => (
                            <button 
                            key={product.id} 
                            onClick={() => addToCart(product)}
                            disabled={product.stock === 0}
                            className={`group text-left bg-white p-2 rounded-xl shadow-[0_2px_10px_rgba(212,175,55,0.05)] hover:shadow-lg transition-all border border-transparent hover:border-gold-200 ${product.stock === 0 ? 'opacity-50 grayscale' : ''}`}
                            >
                            <div className="aspect-[3/4] w-full mb-3 rounded-lg overflow-hidden bg-caramel-50 relative">
                                <img src={product.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                                {product.stock === 0 && (
                                    <div className="absolute inset-0 flex items-center justify-center bg-black/10 backdrop-blur-[1px]">
                                        <span className="bg-white/90 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest text-caramel-800">Esgotado</span>
                                    </div>
                                )}
                            </div>
                            <div className="px-1">
                                <p className="text-[9px] text-gold-500 font-bold uppercase tracking-wider mb-0.5">{product.category}</p>
                                <h4 className="font-serif text-caramel-800 text-sm leading-tight mb-2 truncate w-full">{product.name}</h4>
                                <div className="flex justify-between items-center w-full border-t border-caramel-50 pt-2">
                                    <span className="text-caramel-800 text-sm font-bold">R$ {product.price}</span>
                                </div>
                            </div>
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* Cart Sidebar */}
            <div className={`
                lg:w-[380px] bg-white lg:rounded-3xl lg:border lg:border-caramel-100 lg:shadow-xl lg:h-full lg:flex lg:flex-col
                fixed bottom-20 left-4 right-4 top-auto rounded-3xl shadow-2xl border border-caramel-50 z-30 p-4
                ${cart.length > 0 ? 'flex flex-col' : 'hidden lg:flex'}
            `}>
                <div className="flex justify-between items-center mb-4 lg:p-6 lg:mb-0 lg:border-b lg:border-caramel-50">
                    <div className="flex items-center gap-2">
                        <ShoppingBag size={18} className="text-gold-500" />
                        <h3 className="font-serif text-lg text-caramel-800 italic">Sua Sacola</h3>
                    </div>
                    <span className="bg-gold-50 text-gold-700 text-xs font-bold px-2 py-1 rounded-full">{cart.reduce((a,b)=>a+b.quantity,0)} itens</span>
                </div>

                <div className="flex-1 overflow-y-auto lg:p-6 max-h-[200px] lg:max-h-none space-y-4 mb-4 lg:mb-0">
                    {cart.length === 0 ? (
                        <div className="hidden lg:flex h-full flex-col items-center justify-center text-caramel-300 text-center">
                            <ShoppingBag size={48} strokeWidth={1} className="mb-2 opacity-50" />
                            <p className="text-sm font-serif italic">Selecione peças para iniciar</p>
                        </div>
                    ) : (
                        cart.map(item => (
                            <div key={item.id} className="flex gap-3 items-center">
                                <img src={item.image} className="w-12 h-16 object-cover rounded-md bg-caramel-50" />
                                <div className="flex-1 min-w-0">
                                    <p className="text-xs text-caramel-800 font-serif truncate">{item.name}</p>
                                    <p className="text-xs text-caramel-500">R$ {item.price}</p>
                                </div>
                                <div className="flex items-center bg-caramel-50 rounded-lg border border-caramel-100 h-8">
                                    <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-full flex items-center justify-center text-caramel-400 hover:text-caramel-800"><Minus size={12}/></button>
                                    <span className="text-xs font-bold w-4 text-center text-caramel-800">{item.quantity}</span>
                                    <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-full flex items-center justify-center text-caramel-400 hover:text-caramel-800"><Plus size={12}/></button>
                                </div>
                            </div>
                        ))
                    )}
                </div>

                <div className="lg:p-6 lg:bg-caramel-50/50 lg:rounded-b-3xl">
                    <div className="flex justify-between items-end mb-4">
                        <span className="text-xs uppercase tracking-widest text-caramel-400">Total</span>
                        <span className="font-serif text-2xl text-caramel-900">R$ {subtotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                    </div>
                    <button 
                        onClick={() => setStep('CHECKOUT')}
                        className="w-full bg-caramel-800 text-gold-50 py-4 rounded-xl font-bold text-xs uppercase tracking-[0.2em] hover:bg-gold-600 transition-colors shadow-lg flex items-center justify-center gap-2"
                    >
                        <span>Finalizar</span>
                        <ArrowRight size={14} />
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* --- STEP: CHECKOUT --- */}
      {step === 'CHECKOUT' && (
        <div className="max-w-2xl mx-auto pt-4 h-full animate-fade-in pb-20">
            <button onClick={() => setStep('SHOP')} className="flex items-center gap-2 text-caramel-400 hover:text-gold-600 mb-6 transition-colors">
                <ArrowLeft size={16} /> <span className="text-xs font-bold uppercase tracking-widest">Voltar para Loja</span>
            </button>
            
            <h2 className="font-serif text-3xl text-caramel-800 italic mb-8 border-b border-caramel-100 pb-4">Checkout</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Coluna 1: Pagamento */}
                <div>
                    <h3 className="text-xs font-bold text-gold-600 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <CreditCard size={14}/> 1. Pagamento
                    </h3>
                    <div className="space-y-3">
                        {[
                            { id: 'CARTAO', icon: CreditCard, label: 'Cartão' },
                            { id: 'PIX', icon: QrCode, label: 'Pix' },
                            { id: 'DINHEIRO', icon: Banknote, label: 'Dinheiro' },
                            { id: 'CREDITO_LOJA', icon: Calendar, label: 'A Prazo (Fiado)' }
                        ].map((method) => (
                        <div key={method.id}>
                            <button
                                onClick={() => {
                                    setPaymentMethod(method.id as PaymentMethod);
                                    if(method.id !== 'CARTAO') setInstallments(1);
                                }}
                                className={`w-full p-4 rounded-xl border flex items-center gap-4 transition-all ${
                                paymentMethod === method.id 
                                    ? 'bg-caramel-800 text-gold-100 border-caramel-800 shadow-md transform scale-[1.02]' 
                                    : 'bg-white text-caramel-500 border-caramel-100 hover:border-gold-300'
                                }`}
                            >
                                <method.icon size={20} className={paymentMethod === method.id ? 'text-gold-400' : 'text-caramel-300'} />
                                <span className="text-xs uppercase tracking-wider font-bold">{method.label}</span>
                                {paymentMethod === method.id && <CheckCircle size={16} className="ml-auto text-gold-400" />}
                            </button>
                            
                            {/* Sub-opções: Parcelas do Cartão */}
                            {paymentMethod === 'CARTAO' && method.id === 'CARTAO' && (
                                <div className="mt-2 pl-4 animate-fade-in">
                                    <select 
                                        value={installments}
                                        onChange={(e) => setInstallments(Number(e.target.value))}
                                        className="w-full bg-caramel-50 border border-caramel-200 text-caramel-800 text-xs rounded-lg p-2 outline-none focus:border-gold-400"
                                    >
                                        {[1,2,3,4,5,6,7,8,9,10,11,12].map(num => (
                                            <option key={num} value={num}>
                                                {num}x de R$ {(subtotal / num).toFixed(2)} {num === 1 ? '(À vista)' : '(Sem juros)'}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            )}

                             {/* Sub-opções: Data de Vencimento (Fiado) */}
                            {paymentMethod === 'CREDITO_LOJA' && method.id === 'CREDITO_LOJA' && (
                                <div className="mt-3 bg-caramel-50 p-4 rounded-xl border border-caramel-100 animate-fade-in">
                                    <p className="text-[10px] font-bold text-caramel-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                                        <CalendarDays size={12}/> Data de Vencimento
                                    </p>
                                    
                                    {/* Quick Buttons */}
                                    <div className="flex gap-2 mb-3">
                                        {[15, 30, 45].map(days => (
                                            <button 
                                                key={days}
                                                onClick={() => handleQuickDate(days)}
                                                className="flex-1 py-1 rounded bg-white border border-caramel-200 text-[10px] font-bold text-caramel-600 hover:border-gold-400 hover:text-gold-600 transition-colors"
                                            >
                                                +{days} Dias
                                            </button>
                                        ))}
                                    </div>

                                    <input 
                                        type="date"
                                        value={dueDate}
                                        onChange={(e) => setDueDate(e.target.value)}
                                        className="w-full p-2 rounded-lg border border-caramel-200 text-sm text-caramel-800 outline-none focus:border-gold-400 bg-white"
                                    />
                                </div>
                            )}
                        </div>
                        ))}
                    </div>
                </div>

                {/* Coluna 2: Cliente */}
                <div>
                    <h3 className="text-xs font-bold text-gold-600 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <User size={14}/> 2. Identificação
                    </h3>
                    
                    <div className="bg-white p-6 rounded-2xl border border-caramel-100 shadow-sm relative">
                        {!selectedCustomerId ? (
                            <>
                                <div className="flex justify-between items-center mb-4">
                                    <span className="text-[10px] text-caramel-400 uppercase tracking-wide">Dados do Cliente</span>
                                    <button 
                                        onClick={() => setIsCustomerSearchOpen(!isCustomerSearchOpen)}
                                        className="text-[10px] font-bold text-gold-600 hover:text-gold-500 uppercase tracking-wide border-b border-gold-200"
                                    >
                                        {isCustomerSearchOpen ? 'Fechar Busca' : 'Buscar Cliente'}
                                    </button>
                                </div>

                                {isCustomerSearchOpen && (
                                    <div className="mb-4 animate-fade-in bg-caramel-50 p-3 rounded-xl">
                                        <div className="relative mb-2">
                                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-caramel-400" size={14} />
                                            <input 
                                                autoFocus
                                                className="w-full pl-9 pr-2 py-2 text-sm rounded-lg border border-caramel-200 focus:border-gold-400 outline-none text-caramel-800"
                                                placeholder="Digite para buscar..."
                                                value={customerSearchTerm}
                                                onChange={e => setCustomerSearchTerm(e.target.value)}
                                            />
                                        </div>
                                        <div className="max-h-40 overflow-y-auto space-y-1">
                                            {filteredCustomers.map(c => (
                                                <button 
                                                    key={c.id}
                                                    onClick={() => handleSelectExistingCustomer(c)}
                                                    className="w-full text-left p-2 text-xs text-caramel-800 hover:bg-white rounded-lg flex justify-between"
                                                >
                                                    <span>{c.name}</span>
                                                    {c.balance > 0 && <span className="text-red-500 font-bold">Devendo</span>}
                                                </button>
                                            ))}
                                            {filteredCustomers.length === 0 && customerSearchTerm && (
                                                <p className="text-xs text-caramel-400 text-center py-2">Nenhum encontrado</p>
                                            )}
                                        </div>
                                    </div>
                                )}

                                <div className="space-y-4">
                                    <div>
                                        <label className="block text-[10px] font-bold text-caramel-400 uppercase tracking-widest mb-1">Nome Completo *</label>
                                        <div className="flex items-center gap-2 border-b-2 border-caramel-100 focus-within:border-gold-400 transition-colors py-1">
                                            <User size={16} className="text-caramel-300"/>
                                            <input 
                                                value={customerName}
                                                onChange={e => setCustomerName(e.target.value)}
                                                className="w-full outline-none bg-transparent text-caramel-800 font-serif text-lg placeholder:text-caramel-200"
                                                placeholder="Nome do cliente"
                                            />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-bold text-caramel-400 uppercase tracking-widest mb-1">
                                            Telefone {paymentMethod === 'CREDITO_LOJA' ? '*' : '(Opcional)'}
                                        </label>
                                        <div className="flex items-center gap-2 border-b-2 border-caramel-100 focus-within:border-gold-400 transition-colors py-1">
                                            <Phone size={16} className="text-caramel-300"/>
                                            <input 
                                                type="tel"
                                                value={customerPhone}
                                                onChange={e => setCustomerPhone(e.target.value)}
                                                className="w-full outline-none bg-transparent text-caramel-800 font-sans text-base placeholder:text-caramel-200"
                                                placeholder="(00) 00000-0000"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </>
                        ) : (
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-full bg-gold-50 flex items-center justify-center text-gold-600 font-bold font-serif">
                                        {customerName.charAt(0)}
                                    </div>
                                    <div>
                                        <p className="font-bold text-caramel-800 text-sm">{customerName}</p>
                                        <p className="text-xs text-caramel-400">{customerPhone || 'Sem telefone'}</p>
                                    </div>
                                </div>
                                <button onClick={clearCustomer} className="p-2 hover:bg-red-50 text-caramel-300 hover:text-red-500 rounded-full transition-colors">
                                    <UserPlus size={18} />
                                </button>
                            </div>
                        )}
                    </div>

                    {paymentMethod === 'CREDITO_LOJA' && (
                        <div className="mt-4 p-3 bg-red-50 border border-red-100 rounded-xl flex gap-2 items-start">
                            <AlertCircle size={16} className="text-red-400 mt-0.5 shrink-0" />
                            <p className="text-[10px] text-red-600 leading-tight">
                                Atenção: Ao confirmar, o valor será adicionado ao <strong>saldo devedor</strong> do cliente. Telefone é obrigatório.
                            </p>
                        </div>
                    )}
                </div>
            </div>

            <div className="mt-10 border-t border-caramel-100 pt-6">
                <div className="flex justify-between items-end mb-6">
                    <div>
                        <p className="text-xs uppercase tracking-widest text-caramel-400 mb-1">Total da Venda</p>
                        <p className="font-serif text-4xl text-caramel-900">R$ {subtotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                    </div>
                    <button 
                        onClick={handleCheckout}
                        disabled={status === 'PROCESSING'}
                        className="bg-gold-500 text-white px-10 py-4 rounded-xl font-bold text-sm tracking-[0.2em] uppercase hover:bg-gold-600 transition-colors shadow-lg shadow-gold-200 flex items-center gap-3 transform hover:-translate-y-1"
                    >
                        {status === 'PROCESSING' ? <Loader2 className="animate-spin" /> : <CheckCircle />}
                        Confirmar Venda
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};