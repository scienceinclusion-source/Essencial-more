
import React from 'react';
import { ViewState } from '../types';
import { ShoppingBag, Package, Users, Clock, LogOut, Sparkles } from 'lucide-react';

interface LayoutProps {
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ currentView, onNavigate, children }) => {
  
  // Mobile Header Component
  const MobileHeader = () => (
    <div className="md:hidden fixed top-0 left-0 w-full h-24 bg-white/90 backdrop-blur-md border-b border-caramel-100 z-40 flex flex-col items-center justify-center shadow-sm">
      <h1 className="text-2xl font-serif text-caramel-800 italic tracking-wide">
        Essencial <span className="font-sans font-light text-sm uppercase tracking-[0.2em] text-gold-400 ml-1">More</span>
      </h1>
      <span className="text-[10px] uppercase tracking-[0.3em] text-caramel-400 mt-1 font-light">Maison & Boutique</span>
      
      {/* Decorative Stars */}
      <Sparkles size={12} className="absolute top-8 left-6 text-gold-300" />
      <Sparkles size={12} className="absolute top-8 right-6 text-gold-300" />
    </div>
  );

  // Bottom Navigation (Mobile)
  const BottomNav = () => (
    <div className="md:hidden fixed bottom-0 left-0 w-full bg-white/90 backdrop-blur-xl border-t border-caramel-100 pb-safe z-40 flex justify-around items-end h-20 shadow-[0_-4px_30px_rgba(237,224,212,0.4)]">
      {[
        { view: 'POS', icon: ShoppingBag, label: 'Vender' },
        { view: 'INVENTORY', icon: Package, label: 'Estoque' },
        { view: 'CUSTOMERS', icon: Users, label: 'Clientes' },
        { view: 'DASHBOARD', icon: Clock, label: 'Histórico' },
      ].map((item) => (
        <button
          key={item.view}
          onClick={() => onNavigate(item.view as ViewState)}
          className={`flex flex-col items-center justify-center w-full h-full pb-2 transition-all duration-300 ${
            currentView === item.view ? 'text-gold-500 scale-105' : 'text-caramel-300 hover:text-caramel-500'
          }`}
        >
          <div className={`p-1 rounded-full mb-1 transition-all ${currentView === item.view ? '-translate-y-1 bg-gold-50' : ''}`}>
             <item.icon size={20} strokeWidth={currentView === item.view ? 2 : 1.5} />
          </div>
          <span className="text-[9px] uppercase tracking-widest font-bold">{item.label}</span>
        </button>
      ))}
    </div>
  );

  // Desktop Sidebar - Agora com fundo creme suave, não branco puro
  const Sidebar = () => (
    <aside className="hidden md:flex flex-col w-80 bg-caramel-50/50 backdrop-blur-sm border-r border-caramel-200/60 z-50 h-screen sticky top-0">
      <div className="h-40 flex flex-col items-center justify-center border-b border-caramel-100 bg-transparent">
        <h1 className="text-4xl font-serif text-caramel-800 italic tracking-wide">Essencial</h1>
        <span className="text-xs font-sans uppercase tracking-[0.4em] text-gold-500 mt-2">More</span>
      </div>

      <nav className="flex-1 py-12 px-6 space-y-3">
        {[
          { view: 'POS', icon: ShoppingBag, label: 'Nova Venda' },
          { view: 'INVENTORY', icon: Package, label: 'Acervo & Estoque' },
          { view: 'CUSTOMERS', icon: Users, label: 'Carteira de Clientes' },
          { view: 'DASHBOARD', icon: Clock, label: 'Visão Geral & Histórico' },
        ].map((item) => {
          const isActive = currentView === item.view;
          return (
            <button
              key={item.view}
              onClick={() => onNavigate(item.view as ViewState)}
              className={`w-full flex items-center gap-4 px-6 py-5 rounded-2xl transition-all duration-500 group ${
                isActive 
                  ? 'bg-white text-caramel-800 shadow-[0_4px_20px_rgba(212,175,55,0.1)] border border-caramel-100' 
                  : 'text-caramel-400 hover:bg-white/60 hover:text-caramel-600'
              }`}
            >
              <item.icon 
                size={20} 
                className={`transition-transform duration-500 ${isActive ? 'scale-110 text-gold-400' : 'group-hover:scale-110'}`} 
              />
              <span className={`text-xs uppercase tracking-[0.15em] font-bold ${isActive ? 'text-caramel-800' : ''}`}>
                {item.label}
              </span>
            </button>
          )
        })}
      </nav>

      <div className="p-8 border-t border-caramel-100">
        <button className="flex items-center gap-3 text-caramel-400 hover:text-caramel-600 transition-colors text-xs font-bold tracking-widest uppercase w-full justify-center opacity-70 hover:opacity-100">
            <LogOut size={16} />
            <span>Sair do Sistema</span>
        </button>
      </div>
    </aside>
  );

  return (
    <div className="flex min-h-screen bg-caramel-50 font-sans text-caramel-800">
      <MobileHeader />
      <Sidebar />
      
      <main className="flex-1 relative flex flex-col h-screen overflow-hidden">
        {/* Decorative Top Bar Desktop */}
        <div className="hidden md:flex h-20 items-center justify-end px-10 border-b border-caramel-100/50 bg-caramel-50/80 backdrop-blur-sm sticky top-0 z-40">
           <span className="text-xs font-serif italic text-caramel-400 flex items-center gap-2">
             <Sparkles size={10} className="text-gold-300"/> Maison & Boutique Management System
           </span>
        </div>

        <div className="flex-1 overflow-y-auto pt-28 pb-24 md:pt-8 md:pb-8 px-6 md:px-12 scroll-smooth no-scrollbar">
          <div className="max-w-7xl mx-auto h-full">
            {children}
          </div>
        </div>
      </main>

      <BottomNav />
    </div>
  );
};
