
import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { Inventory } from './components/Inventory';
import { POS } from './components/POS';
import { Customers } from './components/Customers';
import { Product, Customer, Sale, ViewState, CartItem, PaymentMethod } from './types';
import { StorageService } from './services/storage';
import { Loader2 } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('DASHBOARD');
  
  // Data States
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load Initial Data
  const refreshData = async () => {
    try {
      const p = await StorageService.getProducts();
      const c = await StorageService.getCustomers();
      const s = await StorageService.getSales();
      setProducts(p);
      setCustomers(c);
      setSales(s);
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
    }
  };

  useEffect(() => {
    const init = async () => {
        try {
            await StorageService.initDB();
            await refreshData();
        } catch (e) {
            console.error("Falha fatal ao iniciar DB", e);
        } finally {
            setIsLoading(false);
        }
    };
    init();
  }, []);

  const handleAddProduct = async (product: Product) => {
    setIsLoading(true);
    await StorageService.saveProduct(product);
    await refreshData();
    setIsLoading(false);
  };

  const handleUpdateProduct = async (product: Product) => {
    setIsLoading(true);
    await StorageService.saveProduct(product);
    await refreshData();
    setIsLoading(false);
  };

  const handleDeleteProduct = async (id: string) => {
    setIsLoading(true);
    await StorageService.deleteProduct(id);
    await refreshData();
    setIsLoading(false);
  };

  const handleAddCustomer = async (customer: Customer) => {
    setIsLoading(true);
    await StorageService.saveCustomer(customer);
    await refreshData();
    setIsLoading(false);
  };

  const handleDeleteCustomer = async (id: string) => {
     setIsLoading(true);
     await StorageService.deleteCustomer(id);
     await refreshData();
     setIsLoading(false);
  };

  const handleCompleteSale = async (items: CartItem[], customerId: string | null, payment: PaymentMethod, installments: number, dueDate?: string) => {
    setIsLoading(true);
    const result = await StorageService.processSale(items, customerId, payment, installments, dueDate);
    
    if (result.success) {
      await refreshData();
    } else {
      setIsLoading(false); // Stop loading to show error
      throw new Error(result.message);
    }
    setIsLoading(false);
  };

  const handleProcessDebt = async (customerId: string, amount: number, method: PaymentMethod) => {
     setIsLoading(true);
     const result = await StorageService.processDebtPayment(customerId, amount, method);
     
     if (result.success) {
         await refreshData();
     } else {
         alert(result.message);
     }
     setIsLoading(false);
  };

  const handleDeleteSale = async (saleId: string) => {
      setIsLoading(true);
      const result = await StorageService.deleteSale(saleId);
      if (result.success) {
          await refreshData();
      } else {
          alert(result.message);
      }
      setIsLoading(false);
  };

  return (
    <Layout currentView={currentView} onNavigate={setCurrentView}>
      
      {currentView === 'DASHBOARD' && <Dashboard sales={sales} products={products} customers={customers} />}
      {currentView === 'INVENTORY' && (
        <Inventory 
          products={products} 
          onAddProduct={handleAddProduct} 
          onUpdateProduct={handleUpdateProduct} 
          onDeleteProduct={handleDeleteProduct} 
        />
      )}
      {currentView === 'POS' && (
        <POS 
          products={products} 
          customers={customers} 
          onCompleteSale={handleCompleteSale} 
          onAddCustomer={handleAddCustomer}
        />
      )}
      {currentView === 'CUSTOMERS' && (
        <Customers 
          customers={customers} 
          sales={sales} 
          onAddCustomer={handleAddCustomer} 
          onProcessPayment={handleProcessDebt}
          onDeleteCustomer={handleDeleteCustomer}
          onDeleteSale={handleDeleteSale}
        />
      )}
    </Layout>
  );
};

export default App;
