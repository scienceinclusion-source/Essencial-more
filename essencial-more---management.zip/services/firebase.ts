// Este arquivo foi depreciado em favor do services/storage.ts
// O sistema agora utiliza localStorage para persistência de dados.
export {};
