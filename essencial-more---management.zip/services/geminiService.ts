import { GoogleGenAI } from "@google/genai";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

export const generateProductDescription = async (productName: string, category: string): Promise<string> => {
  const ai = getClient();
  if (!ai) {
    return "Descrição automática indisponível (Chave API não configurada).";
  }

  try {
    const prompt = `Crie uma descrição curta, sofisticada e elegante para um produto de moda.
    Produto: ${productName}
    Categoria: ${category}
    
    A loja chama-se 'Essencial More'. O tom deve ser premium, focando em qualidade e estilo atemporal.
    Limite a 2 frases.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Descrição não gerada.";
  } catch (error) {
    console.error("Erro ao gerar descrição:", error);
    return "Erro ao conectar com a IA.";
  }
};
