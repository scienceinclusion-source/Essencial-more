
import { Product, Customer, Sale, CartItem, PaymentMethod } from '../types';

// --- CONFIGURAÇÃO ---
const DB_NAME = 'EssencialMoreDB';
const DB_VERSION = 1;
const STORES = {
  PRODUCTS: 'products',
  CUSTOMERS: 'customers',
  SALES: 'sales'
};

// --- INTERFACES INTERNAS ---
interface DatabaseSchema {
  products: Product[];
  customers: Customer[];
  sales: Sale[];
  meta: {
    version: string;
    exportedAt: string;
  };
}

// --- HELPER FUNCTIONS ---
const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
};

// --- CLASSE DO BANCO DE DADOS (INDEXEDDB) ---

export const StorageService = {
  
  // Inicializa o banco e cria as stores se necessário
  initDB: (): Promise<IDBDatabase> => {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = (event) => {
        console.error("Erro ao abrir banco de dados:", (event.target as any).error);
        reject("Erro ao carregar sistema de dados.");
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        if (!db.objectStoreNames.contains(STORES.PRODUCTS)) {
          db.createObjectStore(STORES.PRODUCTS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORES.CUSTOMERS)) {
          db.createObjectStore(STORES.CUSTOMERS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORES.SALES)) {
          db.createObjectStore(STORES.SALES, { keyPath: 'id' });
        }
      };

      request.onsuccess = (event) => {
        resolve((event.target as IDBOpenDBRequest).result);
      };
    });
  },

  // --- MÉTODOS GENÉRICOS ---

  getAll: async <T>(storeName: string): Promise<T[]> => {
    const db = await StorageService.initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  },

  add: async <T>(storeName: string, item: T): Promise<void> => {
    const db = await StorageService.initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.add(item);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  put: async <T>(storeName: string, item: T): Promise<void> => {
    const db = await StorageService.initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.put(item);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  delete: async (storeName: string, id: string): Promise<void> => {
    const db = await StorageService.initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.delete(id);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  getById: async <T>(storeName: string, id: string): Promise<T | undefined> => {
    const db = await StorageService.initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.get(id);

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  },

  // --- PRODUTOS ---
  
  getProducts: async (): Promise<Product[]> => {
    return await StorageService.getAll<Product>(STORES.PRODUCTS);
  },

  saveProduct: async (product: Product): Promise<void> => {
    if (!product.name || product.price < 0) {
      throw new Error("Produto inválido: Nome obrigatório e preço deve ser positivo.");
    }

    const allProducts = await StorageService.getProducts();

    if (product.id) {
        // Update
        await StorageService.put(STORES.PRODUCTS, { ...product, stock: Number(product.stock) });
    } else {
        // Create - Check duplicate name
        const exists = allProducts.some(p => p.name.toLowerCase() === product.name.trim().toLowerCase());
        if (exists) throw new Error("Já existe um produto com este nome exato.");

        const newProduct: Product = { 
            ...product, 
            id: generateId(),
            stock: Number(product.stock),
            name: product.name.trim(),
            image: product.image || ''
        };
        await StorageService.add(STORES.PRODUCTS, newProduct);
    }
  },

  deleteProduct: async (id: string): Promise<void> => {
    await StorageService.delete(STORES.PRODUCTS, id);
  },

  // --- CLIENTES ---

  getCustomers: async (): Promise<Customer[]> => {
    const customers = await StorageService.getAll<Customer>(STORES.CUSTOMERS);
    return customers.map(c => ({
      ...c,
      balance: Number(c.balance) || 0,
      totalSpent: Number(c.totalSpent) || 0,
      purchaseHistory: Array.isArray(c.purchaseHistory) ? c.purchaseHistory : []
    }));
  },

  saveCustomer: async (customer: Customer): Promise<void> => {
    if (!customer.name) throw new Error("Nome do cliente é obrigatório.");

    if (customer.id) {
       await StorageService.put(STORES.CUSTOMERS, customer);
    } else {
       const newCustomer: Customer = {
        ...customer,
        id: generateId(),
        balance: 0,
        totalSpent: 0,
        purchaseHistory: []
      };
      await StorageService.add(STORES.CUSTOMERS, newCustomer);
    }
  },

  deleteCustomer: async (id: string): Promise<void> => {
    await StorageService.delete(STORES.CUSTOMERS, id);
  },

  // --- VENDAS ---

  getSales: async (): Promise<Sale[]> => {
    const sales = await StorageService.getAll<Sale>(STORES.SALES);
    // Ordenar por data decrescente
    return sales.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  },

  // --- TRANSAÇÃO DE VENDA COMPLEXA ---
  processSale: async (
    items: CartItem[], 
    customerId: string | null, 
    paymentMethod: PaymentMethod,
    installments: number = 1,
    dueDate?: string
  ): Promise<{ success: boolean; message?: string }> => {
    const db = await StorageService.initDB();
    
    return new Promise((resolve, reject) => {
      // Abre transação multi-store
      const transaction = db.transaction([STORES.PRODUCTS, STORES.CUSTOMERS, STORES.SALES], 'readwrite');
      
      const productStore = transaction.objectStore(STORES.PRODUCTS);
      const customerStore = transaction.objectStore(STORES.CUSTOMERS);
      const saleStore = transaction.objectStore(STORES.SALES);

      let saleTotal = 0;
      const saleId = generateId();
      let customerName = "Cliente Não Identificado";

      transaction.onabort = () => {
         resolve({ success: false, message: transaction.error?.message || "Transação abortada." });
      };

      transaction.oncomplete = () => {
         resolve({ success: true });
      };

      transaction.onerror = (e) => {
         resolve({ success: false, message: (e.target as any).error?.message });
      };

      // 1. Validar e Atualizar Produtos
      const processProducts = async () => {
        try {
            for (const item of items) {
                const productReq = productStore.get(item.id);
                
                await new Promise<void>((res, rej) => {
                    productReq.onsuccess = () => {
                        const product = productReq.result as Product;
                        if (!product) {
                            transaction.abort();
                            return rej("Produto não encontrado.");
                        }
                        if (product.stock < item.quantity) {
                            // Não aborta a transação inteira via throw, mas precisamos parar o fluxo
                            // Vamos forçar erro para cair no catch
                            transaction.abort(); 
                            return rej(`Estoque insuficiente para: ${product.name}`);
                        }

                        // Atualiza estoque
                        product.stock -= item.quantity;
                        productStore.put(product);
                        saleTotal += (product.price * item.quantity);
                        res();
                    };
                    productReq.onerror = () => rej("Erro ao ler produto.");
                });
            }

            // 2. Atualizar Cliente (se houver)
            if (customerId) {
                const custReq = customerStore.get(customerId);
                await new Promise<void>((res, rej) => {
                    custReq.onsuccess = () => {
                        const customer = custReq.result as Customer;
                        if (customer) {
                            customerName = customer.name;
                            customer.totalSpent = (customer.totalSpent || 0) + saleTotal;
                            
                            if (paymentMethod === 'CREDITO_LOJA') {
                                customer.balance = (customer.balance || 0) + saleTotal;
                            }
                            
                            customer.purchaseHistory = [saleId, ...(customer.purchaseHistory || [])];
                            customerStore.put(customer);
                        } else if (paymentMethod === 'CREDITO_LOJA') {
                            transaction.abort();
                            return rej("Cliente obrigatório para venda a prazo.");
                        }
                        res();
                    };
                    custReq.onerror = () => rej("Erro ao ler cliente.");
                });
            } else if (paymentMethod === 'CREDITO_LOJA') {
                transaction.abort();
                throw new Error("Venda a Prazo exige identificação do cliente.");
            }

            // 3. Criar Venda
            const saleRecord: Sale = {
                id: saleId,
                type: 'SALE',
                customerId,
                customerName,
                date: new Date().toISOString(),
                dueDate: dueDate,
                items: items.map(i => ({
                    productId: i.id,
                    productName: i.name,
                    quantity: i.quantity,
                    priceAtSale: i.price
                })),
                total: saleTotal,
                paymentMethod,
                installments: paymentMethod === 'CARTAO' ? installments : 1
            };

            saleStore.add(saleRecord);

        } catch (error: any) {
            // Se algo falhar dentro da lógica async, garantimos que a transação já foi abortada
            console.error("Erro interno na venda:", error);
            // transaction.abort() já deve ter sido chamado nos rej()
        }
      };

      processProducts();
    });
  },

  // --- PAGAMENTO DE DÍVIDA ---
  processDebtPayment: async (customerId: string, amount: number, paymentMethod: PaymentMethod): Promise<{ success: boolean; message?: string }> => {
    const db = await StorageService.initDB();

    return new Promise((resolve) => {
        const transaction = db.transaction([STORES.CUSTOMERS, STORES.SALES], 'readwrite');
        const customerStore = transaction.objectStore(STORES.CUSTOMERS);
        const saleStore = transaction.objectStore(STORES.SALES);
        const saleId = generateId();

        transaction.oncomplete = () => resolve({ success: true });
        transaction.onerror = (e) => resolve({ success: false, message: (e.target as any).error?.message });

        const custReq = customerStore.get(customerId);
        custReq.onsuccess = () => {
            const customer = custReq.result as Customer;
            if (!customer) {
                // abort handled by logic flow check usually, but here we just return
                return;
            }

            const newBalance = Math.max(0, (customer.balance || 0) - amount);
            customer.balance = newBalance;
            customer.purchaseHistory = [saleId, ...(customer.purchaseHistory || [])];
            customerStore.put(customer);

            const paymentRecord: Sale = {
                id: saleId,
                type: 'DEBT_PAYMENT',
                customerId,
                customerName: customer.name,
                date: new Date().toISOString(),
                items: [],
                total: amount,
                paymentMethod,
                observation: 'Abatimento de Dívida'
            };
            saleStore.add(paymentRecord);
        };
    });
  },

  // --- ESTORNO / EXCLUSÃO DE VENDA ---
  deleteSale: async (saleId: string): Promise<{ success: boolean; message?: string }> => {
    const db = await StorageService.initDB();

    return new Promise((resolve) => {
        const transaction = db.transaction([STORES.PRODUCTS, STORES.CUSTOMERS, STORES.SALES], 'readwrite');
        const productStore = transaction.objectStore(STORES.PRODUCTS);
        const customerStore = transaction.objectStore(STORES.CUSTOMERS);
        const saleStore = transaction.objectStore(STORES.SALES);

        transaction.oncomplete = () => resolve({ success: true });
        transaction.onerror = (e) => resolve({ success: false, message: (e.target as any).error?.message });

        const saleReq = saleStore.get(saleId);
        saleReq.onsuccess = () => {
            const sale = saleReq.result as Sale;
            if (!sale) return; // Venda já não existe

            // 1. Reverter Estoque
            if (sale.type === 'SALE' && sale.items) {
                sale.items.forEach(item => {
                    const prodReq = productStore.get(item.productId);
                    prodReq.onsuccess = () => {
                        const prod = prodReq.result as Product;
                        if (prod) {
                            prod.stock += item.quantity;
                            productStore.put(prod);
                        }
                    };
                });
            }

            // 2. Reverter Financeiro
            if (sale.customerId) {
                const custReq = customerStore.get(sale.customerId);
                custReq.onsuccess = () => {
                    const cust = custReq.result as Customer;
                    if (cust) {
                         if (sale.type === 'SALE') {
                            cust.totalSpent = Math.max(0, cust.totalSpent - sale.total);
                            if (sale.paymentMethod === 'CREDITO_LOJA') {
                                cust.balance = Math.max(0, cust.balance - sale.total);
                            }
                         } else if (sale.type === 'DEBT_PAYMENT') {
                             cust.balance = cust.balance + sale.total;
                         }
                         cust.purchaseHistory = cust.purchaseHistory.filter(id => id !== saleId);
                         customerStore.put(cust);
                    }
                };
            }

            // 3. Deletar Venda
            saleStore.delete(saleId);
        };
    });
  },

  // --- IMPORT / EXPORT ---
  
  exportDatabase: async (): Promise<string> => {
    const products = await StorageService.getAll<Product>(STORES.PRODUCTS);
    const customers = await StorageService.getAll<Customer>(STORES.CUSTOMERS);
    const sales = await StorageService.getAll<Sale>(STORES.SALES);

    const data: DatabaseSchema = {
      products,
      customers,
      sales,
      meta: {
          version: '2.0',
          exportedAt: new Date().toISOString()
      }
    };
    return JSON.stringify(data, null, 2);
  },

  importDatabase: async (jsonContent: string): Promise<{ success: boolean; message: string }> => {
    try {
      const data = JSON.parse(jsonContent) as DatabaseSchema;
      if (!Array.isArray(data.products) || !Array.isArray(data.customers) || !Array.isArray(data.sales)) {
        throw new Error("Arquivo de backup inválido.");
      }

      const db = await StorageService.initDB();
      const transaction = db.transaction([STORES.PRODUCTS, STORES.CUSTOMERS, STORES.SALES], 'readwrite');

      // Limpar tudo antes de importar
      transaction.objectStore(STORES.PRODUCTS).clear();
      transaction.objectStore(STORES.CUSTOMERS).clear();
      transaction.objectStore(STORES.SALES).clear();

      // Inserir dados
      data.products.forEach(p => transaction.objectStore(STORES.PRODUCTS).add(p));
      data.customers.forEach(c => transaction.objectStore(STORES.CUSTOMERS).add(c));
      data.sales.forEach(s => transaction.objectStore(STORES.SALES).add(s));

      return new Promise((resolve) => {
          transaction.oncomplete = () => resolve({ success: true, message: "Dados restaurados com sucesso!" });
          transaction.onerror = (e) => resolve({ success: false, message: "Erro na transação de importação." });
      });

    } catch (error: any) {
      console.error("Erro na importação:", error);
      return { success: false, message: "Erro ao processar arquivo: " + error.message };
    }
  }
};
